
package interfaces;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
//import java.util.function.Consumer;


public interface Gestionable<T> {    
    void agregar(T elemento);    
    T eliminar(int indice);    
    T obtener(int indice);    
    void limpiarElementos();    
    void ordenar();    
    void ordenar(Comparator<T> comparator);       
    List<T> filtrar(Predicate<T> predicate);    
    void guardarEnBinario(String path);    
    void cargarDesdeBinario(String path);
    void guardarEnCSV(String path);    
    void cargarDesdeCSV(String path, Function<String, T> transformadora);    
    void mostrarTodos();    
}
