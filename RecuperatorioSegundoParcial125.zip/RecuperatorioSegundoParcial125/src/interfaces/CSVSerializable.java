
package interfaces;


public interface CSVSerializable<T>{
    
    String toHeaderCSV();
    String toCSV();
}
