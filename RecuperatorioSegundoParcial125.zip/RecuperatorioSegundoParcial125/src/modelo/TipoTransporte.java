
package modelo;


public enum TipoTransporte {
    AVION, 
    TREN, 
    AUTOBUS, 
    BARCO

}
