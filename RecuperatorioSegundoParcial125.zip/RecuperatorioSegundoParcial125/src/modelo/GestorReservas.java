
package modelo;

import Servicio.ReservaViajeServicio;
import interfaces.CSVSerializable;
import interfaces.Gestionable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Function;
import java.util.function.Predicate;

public class GestorReservas <T extends Comparable & CSVSerializable> implements Gestionable<T>{
    private List<T> datos = new ArrayList<>();
    

    @Override
    public void agregar(T item) {
        if (item == null){
            throw new IllegalArgumentException();
        }
        datos.add(item);
    }

    private boolean validarIndice(int indice){
        Boolean toReturn = true;
        if(indice < 0 || indice >= datos.size()){
            toReturn = false;
        }
          return toReturn;
    }

    @Override
    public T obtener(int indice) {
        if(!validarIndice(indice)){
            throw new IndexOutOfBoundsException();
        }
        return datos.get(indice);
    }


    @Override
    public T eliminar(int indice) {
        if(!validarIndice(indice)){
            throw new NoSuchElementException("El elemento no se encuentra en la lista actualmente.");
        }
        return datos.remove(indice);
    }
    
    
    
    @Override
    public void limpiarElementos() {
        datos.clear();
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        datos.sort(comparator);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicate) {
        List<T> toReturn = new ArrayList<>();
        
        for (T item : datos){
            if(predicate.test(item)){
                toReturn.add(item);
            }
        }        
        return toReturn;
    }

    @Override
    public void guardarEnBinario(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(datos);            
        } catch (IOException ex) {
            System.out.println("Error al serializar: " + ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String path) {
        List<ReservaViaje> toReturn = new ArrayList<>();
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<ReservaViaje>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error al deseriaizar: " + ex.getMessage());
        }
        datos = (List<T>) toReturn;
    }    


    @Override
    public void guardarEnCSV(String path) {
        ReservaViajeServicio.guardarReservaCSV((List<? extends ReservaViaje>) datos, path, datos.get(0).toHeaderCSV());
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> transformadora) {
        datos = (List<T>) ReservaViajeServicio.cargarNavesEspacialesCSV(path, transformadora);
    }

    @Override
    public void mostrarTodos() {
            for(T e: datos){
            System.out.println(e);
        }   
    }
    
}
