
package modelo;

import interfaces.CSVSerializable;
import java.io.Serializable;
import java.time.LocalDate;


public class ReservaViaje extends Reserva implements Comparable<ReservaViaje>, CSVSerializable, Serializable{
    private static final long SerialVersionUID = 2L;
    private String destino;
    private TipoTransporte transporte;

    public ReservaViaje(int id, String pasajero, LocalDate fecha, String destino, TipoTransporte transporte) {
        super(id, pasajero, fecha);
        this.destino = destino;
        this.transporte = transporte;
    }

    @Override
    public int compareTo(ReservaViaje r2) {
        return getFecha().compareTo(r2.getFecha());
    }

    @Override
    public String toHeaderCSV() {
        return "id,pasajero,fecha,transporte";
    }

    @Override
    public String toCSV() {
        return id + "," + pasajero + "," + fecha + "," + destino + "," + transporte;
    }

    @Override
    public String toString() {
        return super.toString() + "," + "destino = " + destino + ", transporte = " + transporte ;
    }
    
    public static ReservaViaje fromCSV(String ReservaViajeCSV){
            String[] values = ReservaViajeCSV.split(",");
            ReservaViaje toReturn = null;
            if(values.length == 5){
                int id = Integer.parseInt(values[0]);
                String pasajero = values[1];
                LocalDate fecha = LocalDate.parse(values[2]);
                String destino = values[3];
                TipoTransporte transporte = TipoTransporte.valueOf(values[4]);               
                toReturn = new ReservaViaje(id, pasajero, fecha, destino, transporte);
        }
        return toReturn;
    } 

    public TipoTransporte getTransporte() {
        return transporte;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getPasajero() {
        return pasajero;
    }
    
}
