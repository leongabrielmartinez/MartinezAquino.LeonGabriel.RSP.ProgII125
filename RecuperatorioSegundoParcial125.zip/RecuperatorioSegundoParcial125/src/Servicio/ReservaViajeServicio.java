
package Servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import modelo.ReservaViaje;


public class ReservaViajeServicio {
    
    public static void guardarReservaCSV(List<? extends ReservaViaje> lista, String path, String header){
        File archivo = new File(path);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){
            
            bw.write(header + "\n");
            for(ReservaViaje e: lista){                
                bw.write(e.toCSV() + "\n");
            }
        }catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public static <T> List<ReservaViaje> cargarNavesEspacialesCSV(String path, Function<String, T> transformadora){
        List<ReservaViaje> toReturn = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(path))){
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null){    
                if(linea.endsWith(("\n"))){
                    linea = linea.substring(linea.length() - 1);                
                }            
                    toReturn.add((ReservaViaje) transformadora.apply(linea));            
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }  
}

