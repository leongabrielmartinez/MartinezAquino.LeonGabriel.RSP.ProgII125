
package config;

import java.nio.file.Path;
import java.nio.file.Paths;


public class AppConfig {
    Path pathArchivos = Paths.get("src/data/");
    Path nombreCSV = Paths.get("reservaviajes.csv");
    Path nombreSerializacion = Paths.get("reservaviajes.bin");
    
    public String PATH_CSV = pathArchivos.resolve(nombreCSV).toString();
    public String PATH_BIN = pathArchivos.resolve(nombreSerializacion).toString();

}
